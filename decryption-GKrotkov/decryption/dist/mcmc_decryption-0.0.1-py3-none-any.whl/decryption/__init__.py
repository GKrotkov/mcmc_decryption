# __init__.py
from likelihood import invert_dictionary, initial_mapping, update_mapping, \
    pct_disagreement, likelihood_exponent, likelihood_exp_diff, \
    likelihood_ratio

from manage_text import preprocess_text, read_text, compute_frequencies, \
    encrypt_text, decrypt_text

# purely to avoid flake8 errors
invert_dictionary, initial_mapping, update_mapping, pct_disagreement
likelihood_exponent, likelihood_exp_diff, likelihood_ratio
preprocess_text, read_text, compute_frequencies, encrypt_text, decrypt_text
